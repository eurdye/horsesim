# Dictionary of possible responses for John
john_responses = {
    'greeting': [
        "I heard one day even the sea will no longer be here...",
        "What is your punishment?",
        "What do you remember?",
        "What have you forgotten?",
        "I've been here longer than I can remember... yet, I remember something more still... "
    ],
    'new_moon_comment': [
        "Oh, would you look at that. It's a new moon right now.",
    ],
}


